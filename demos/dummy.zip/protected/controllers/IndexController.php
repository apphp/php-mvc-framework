<?php

class IndexController extends CController
{
    
	public function __construct()
	{
        parent::__construct();
    }
	
	public function indexAction()
	{
        $this->view->text = 'This is a dummy application!';
        $this->view->render('index/index');
	}
	
}