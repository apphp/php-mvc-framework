<?php

return array(
    // module components
    'components' => array(
        '[MODULE_NAME]Component' => array('enable' => true, 'class' => '[MODULE_NAME]Component'),
    ),

    // url manager (optional)
    //'urlManager' => array(
    //    'rules' => array(
    //        'page/([0-9]+)/(.*?)' => 'page/view/id/{$0}',
    //    ),
    //),    

    // default settings (optional, if defined - will be used as application default settings)
    //'defaultController' => 'controller',
    //'defaultAction' => 'action',
);
