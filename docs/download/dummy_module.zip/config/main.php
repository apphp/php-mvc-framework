<?php

return array(
    // module classes
    'classes' => array(
        '[MODULE_NAME]Component',
        '[MODEL_NAME]',
    ),
    // management links
    'managementLinks' => array(
        A::t('[MODULE_CODE]', '[MODULE_NAME]') => '[MODEL_NAME]/manage'
    ),    
);
