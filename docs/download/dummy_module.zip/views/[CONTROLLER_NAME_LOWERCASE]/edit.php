<!-- register tinymce files -->
<?php // A::app()->getClientScript()->registerScriptFile('js/vendors/tinymce/tiny_mce.js'); ?>
<?php // A::app()->getClientScript()->registerScriptFile('js/vendors/tinymce/config.js'); ?>
<?php // A::app()->getClientScript()->registerCssFile('js/vendors/tinymce/general.css'); ?>

<?php
    $this->_activeMenu = 'modules/settings/code/[MODULE_CODE]';
    $this->_breadCrumbs = array(
        array('label'=>A::t('[MODULE_CODE]', 'Modules'), 'url'=>'modules/'),
        array('label'=>A::t('[MODULE_CODE]', '[MODULE_NAME]'), 'url'=>'modules/settings/code/[MODULE_CODE]'),
        array('label'=>A::t('[MODULE_CODE]', '[CONTROLLER_NAME] Management'), 'url'=>'[MODULE_CODE]/manage'),
        array('label'=>A::t('[MODULE_CODE]', 'Edit [CONTROLLER_NAME]')),
    );
?>

<h1><?= A::t('[MODULE_CODE]', '[CONTROLLER_NAME] Management'); ?></h1>

<div class="bloc">
	<?= $tabs; ?>
		
	<div class="sub-title"><?= A::t('[MODULE_CODE]', 'Edit [CONTROLLER_NAME]'); ?></div>
    <div class="content">
        <?php
			// echo $actionMessage;          
	    ?>
  
    </div>
</div>

<?php 
//if($errorField != ''){
	// A::app()->getClientScript()->registerScript($formName, 'document.forms["'.$formName.'"].'.$errorField.'.focus();', 2);
//}
// A::app()->getClientScript()->registerScript('setTinyMceEditor', 'setEditor("news_text");', 2);
?>  