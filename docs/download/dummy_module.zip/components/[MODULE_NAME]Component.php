<?php
/**
* [MODULE_NAME]Component
*
* PUBLIC:                  	PRIVATE
* -----------              	------------------
* prepareTab
* drawShortcode
* 
* 
* STATIC
* -------------------------------------------
* init
* 
*/

class [MODULE_NAME]Component extends CComponent{

	const NL = "\n";

    public static function init()
	{
	    return parent::init(__CLASS__);
	}

    /**
     * Prepares [MODULE_NAME] module tabs
     * @param string $activeTab
     * @param int $menuCatId
     * @param int $menuCatItemId
     */
    public static function prepareTab($activeTab = 'info', $menuCatId = '', $menuCatItemId = '')
    {
    	return CWidget::create('CTabs', array(
			'tabsWrapper'=>array('tag'=>'div', 'class'=>'title'),
			'tabsWrapperInner'=>array('tag'=>'div', 'class'=>'tabs'),
			'contentWrapper'=>array(),
			'contentMessage'=>'',
			'tabs'=>array(
				A::t('[MODULE_CODE]', 'Settings') => array('href'=>'modules/settings/code/[MODULE_CODE]', 'id'=>'tabSettings', 'content'=>'', 'active'=>false, 'htmlOptions'=>array('class'=>'modules-settings-tab')),
				A::t('[MODULE_CODE]', '[CONTROLLER_NAME]') => array('href'=>'[CONTROLLER_NAME]/index', 'id'=>'tabInfo', 'content'=>'', 'active'=>($activeTab == 'info' ? true : false)),
			),
			'events'=>array(
				//'click'=>array('field'=>$errorField)
			),
			'return'=>true,
    	));
    }

	/**
	 * Draws shortcode output
	 * @param array $params
	 */
	public static function drawShortcode($params = array())
	{
		$output = '';
 
    }
    
}