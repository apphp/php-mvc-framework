<?php return array (
'Add [CONTROLLER_NAME]' => 'Add [CONTROLLER_NAME]',
'Edit [CONTROLLER_NAME]' => 'Edit [CONTROLLER_NAME]',
'Settings' => 'Settings',
'Modules' => 'Modules',

'[CONTROLLER_NAME]' => '[CONTROLLER_NAME]',
'[CONTROLLER_NAME] Management' => '[CONTROLLER_NAME] Management',
'[MODULE_NAME]' => '[MODULE_NAME]',
  
    
);