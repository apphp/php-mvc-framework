
INSERT INTO `<DB_PREFIX>modules` (`id`, `code`, `name`, `description`, `version`, `icon`, `tables`, `show_on_dashboard`, `show_in_menu`, `is_installed`, `is_system`, `is_active`, `sort_order`) VALUES
(NULL, '[MODULE_CODE]', '[MODULE_NAME]', '[MODULE_DESCRIPTION]', '0.0.1', 'icon.png', '', 0, 0, 1, 0, 1, 0);


--INSERT INTO `<DB_PREFIX>module_settings` (`id`, `module_code`, `property_key`, `property_value`, `property_group`, `name`, `description`, `property_type`, `property_source`, `is_required`) VALUES
--(NULL, '[MODULE_CODE]', 'modulelink', '[MODULE_CODE]/viewAll', '', 'All [MODULE_NAME] Link', 'This link leads to the page with all [MODULE_NAME_LC]', 'label', '', 0);
--

--INSERT INTO `<DB_PREFIX>privileges` (`id`, `category`, `code`, `name`, `description`) VALUES (NULL, '[MODEL_CODE]', 'add', 'Add [MODEL_NAME]', 'Add [MODEL_NAME_LC] on the site'); 
--INSERT INTO `<DB_PREFIX>role_privileges` (`id`, `role_id`, `privilege_id`, `is_active`) VALUES (NULL, 1, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 1), (NULL, 2, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 1), (NULL, 3, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 0);
--INSERT INTO `<DB_PREFIX>privileges` (`id`, `category`, `code`, `name`, `description`) VALUES (NULL, '[MODEL_CODE]', 'edit', 'Edit [MODEL_NAME]', 'Edit [MODEL_NAME_LC] on the site'); 
--INSERT INTO `<DB_PREFIX>role_privileges` (`id`, `role_id`, `privilege_id`, `is_active`) VALUES (NULL, 1, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 1), (NULL, 2, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 1), (NULL, 3, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 0);
--INSERT INTO `<DB_PREFIX>privileges` (`id`, `category`, `code`, `name`, `description`) VALUES (NULL, '[MODEL_CODE]', 'delete', 'Delete [MODEL_NAME]', 'Delete [MODEL_NAME_LC] from the site'); 
--INSERT INTO `<DB_PREFIX>role_privileges` (`id`, `role_id`, `privilege_id`, `is_active`) VALUES (NULL, 1, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 1), (NULL, 2, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 1), (NULL, 3, (SELECT MAX(id) FROM `<DB_PREFIX>privileges`), 0);
--

--create here module tables