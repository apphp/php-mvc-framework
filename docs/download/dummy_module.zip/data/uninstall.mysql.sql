
DELETE FROM `<DB_PREFIX>modules` WHERE `code` = '[MODULE_CODE]';
DELETE FROM `<DB_PREFIX>module_settings` WHERE `module_code` = '[MODULE_CODE]';

-- DELETE FROM `<DB_PREFIX>role_privileges` WHERE `privilege_id` IN (SELECT id FROM `<DB_PREFIX>privileges` WHERE `category` = '[MODEL_CODE]' AND `code` = 'add');
-- DELETE FROM `<DB_PREFIX>role_privileges` WHERE `privilege_id` IN (SELECT id FROM `<DB_PREFIX>privileges` WHERE `category` = '[MODEL_CODE]' AND `code` = 'edit');
-- DELETE FROM `<DB_PREFIX>role_privileges` WHERE `privilege_id` IN (SELECT id FROM `<DB_PREFIX>privileges` WHERE `category` = '[MODEL_CODE]' AND `code` = 'delete');
--
-- DELETE FROM `<DB_PREFIX>privileges` WHERE `category` = '[MODEL_CODE]';
-- DELETE FROM `<DB_PREFIX>privileges` WHERE `category` = '[MODULE_CODE]';

-- DROP TABLE IF EXISTS `<DB_PREFIX>[MODEL_TABLE]`;
-- DROP TABLE IF EXISTS `<DB_PREFIX>[MODEL_TABLE]_translations`;


