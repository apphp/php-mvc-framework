<?php

return array(

    // Datetime settings
    'defaultTimeZone' => 'UTC',

    // Application default settings
	'defaultErrorController' => 'Error',				/* may be overridden by module settings */
	'defaultController' => 'Index',						/* may be overridden by module settings */
    'defaultAction' => 'index',							/* may be overridden by module settings */

    // Template default settings  
	'template' => array(
		'default' => 'default'			
	),

	// Layout default settings  
	'layouts' => array(
		'enable' => true, 
		'default' => 'default'
	),
);