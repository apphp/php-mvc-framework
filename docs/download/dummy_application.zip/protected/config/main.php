<?php

return array(
    'defaultTemplate' => '',
	'defaultController' => 'Index',
    'defaultAction' => 'index',	
);