<?php

class IndexController extends CController
{
    
	public function __construct()
	{
        parent::__construct();

        // set backend mode
        // Website::setBackend();
        // set backend mode
        // Website::setFrontend();
    }
	
	public function indexAction()
	{
        $this->_view->text = 'This is a dummy application!';
        $this->_view->render('index/index');
	}
	
}