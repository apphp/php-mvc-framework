<?php

class ErrorController extends CController
{
	
	public function indexAction()
	{
        echo 'Error controller!';
    }
}