<h1><?php echo $text; ?></h1>
